
public class ExistenteException extends RuntimeException {

	private static final long serialVersionUID = -5526486570416507745L;

	public ExistenteException() {
		super("ESSA CONTA J� EXISTE!");
	}
}
