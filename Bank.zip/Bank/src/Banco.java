import java.util.ArrayList;

public class Banco {

	static ArrayList<ContaBancaria> listaContasBancaria = new ArrayList<>();

	public static void inserir(ContaBancaria conta) {
		listaContasBancaria.add(conta);
	}

	public static void remover(ContaBancaria conta) {
		listaContasBancaria.remove(conta);
	}

	public static int procurarConta(int numeroConta) {
		for (int i = 0; i < Banco.listaContasBancaria.size(); i++) {
			if (Banco.listaContasBancaria.get(i).getNumeroConta() == numeroConta) {
				Main.conta = Banco.listaContasBancaria.get(i);
				return i;
			}
		}
		return -1;
	}

	public static String[] mostrarConta() {
		String[] lista = new String[listaContasBancaria.size()];
		for (int i = 0; i < listaContasBancaria.size(); i++) {
			lista[i] = listaContasBancaria.get(i).toString();
		}
		return lista;
	}
}
