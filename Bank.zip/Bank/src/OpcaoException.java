
public class OpcaoException extends RuntimeException{

	private static final long serialVersionUID = -4388486532866822069L;
	
	public OpcaoException() {
		super("OP��O INVAL�DA!");
	}
}
