
public class InexistenteException extends RuntimeException {

	private static final long serialVersionUID = 8025515896995837720L;

	public InexistenteException() {
		super("CONTA INEXISTENTE!");
	}
}