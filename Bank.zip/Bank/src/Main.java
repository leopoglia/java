import java.util.Scanner;

public class Main {
	public static Scanner sc = new Scanner(System.in);
	static int numeroConta, acoes;
	static ContaBancaria conta;

	public static void main(String[] args) {
		System.out.println("BANK OF AMERICA");

		try {
			menu();
		} catch (RuntimeException erro) {
			System.out.println(erro.getMessage());
		} finally {
			main(args);
		}
	}

	public static void menu() {
		System.out.println("MENU PRINCIPAL\n(1) CRIAR CONTA\n(2) SELECIONAR CONTA\n(3) REMOVER CONTA\n(4) GERAR RELAT�RIO\n(5) FINALIZAR");
		int opcao = sc.nextInt();
		
		if(opcao > 5 || opcao < 1) {
			throw new OpcaoException();
		}

		switch (opcao) {
		case 1:
			ContaBancaria conta = coletaDados();
			Banco.inserir(conta);
			break;
		case 2:
			selecionarConta();
			break;
		case 3:
			removerConta();
			break;
		case 4:
			String[] lista = Banco.mostrarConta();
			for (int i = 0; i < lista.length; i++) {
				System.out.println(lista[i]);
			}
			break;
		case 5:
			System.exit(0);
		default:
			System.out.println("Escolha outra op��o!!!");
		}
		menu();
	}

	public static ContaBancaria coletaDados() {
		System.out.println("MENU ESCOLHA\n(1) CONTA CORRENTE\n(2) CONTA POUPAN�A");
		int opcao = sc.nextInt();
		
		if(opcao > 2 || opcao < 1) {
			throw new OpcaoException();
		}

		System.out.print("N�MERO DA CONTA: ");
		int numeroConta = sc.nextInt();

		int contaVerificada = verificarConta(numeroConta);

		if (contaVerificada == -1) {
			if (opcao == 1) {
				System.out.print("DIGITE O LIMITE: ");
				double limite = sc.nextInt();

				return new ContaCorrente(numeroConta, 0, 20, limite);
			} else {
				return new ContaPoupanca(numeroConta, 0, 20);
			}
		} else {
			throw new ExistenteException();
		}
	}

	public static void selecionarConta() {
		System.out.print("DIGITE O N�MERO DA CONTA: ");
		numeroConta = Banco.procurarConta(sc.nextInt());

		if (numeroConta != -1) {
			acoes = 0;
			menuUsuario();
		} else {
			throw new InexistenteException();
		}
	}

	public static void menuUsuario() {
		System.out.println("MENU USU�RIO\n(1) DEPOSITAR\n(2) SACAR\n(3) TRANSFERIR\n(4) GERAR RELAT�RIO\n(5) VOLTAR");
		int opcao = sc.nextInt();
		
		if(opcao > 5 || opcao < 1) {
			throw new OpcaoException();
		}

		switch (opcao) {
		case 1:
			System.out.print("VALOR A SER DEPOSITADO: ");
			conta.depositar(sc.nextDouble());
			break;
		case 2:
			System.out.print("VALOR A SER SACADO: ");
			conta.sacar(sc.nextDouble());
			break;
		case 3:
			System.out.print("CONTA PARA QUAL SER� TRANSFERIDO: ");
			int numeroConta = sc.nextInt();
			int contaVerificada = verificarConta(numeroConta);
			if (contaVerificada != -1) {
				System.out.print("VALOR A SER TRANSFERIDO: ");
				conta.transferir(sc.nextDouble(), Banco.listaContasBancaria.get(contaVerificada));
			} else {
				throw new InexistenteException();
			}
			break;
		case 4:
			gerarRelatorio();
			break;
		}
		menuUsuario();
	}

	public static void removerConta() {
		System.out.print("DIGITE A CONTA A SER REMOVIDA: ");
		int numeroConta = sc.nextInt();
		int contaVerificada = verificarConta(numeroConta);
		if (contaVerificada != -1) {
			Banco.remover(Banco.listaContasBancaria.get(contaVerificada));
		} else {
			throw new InexistenteException();
		}
	}

	public static int verificarConta(int numeroConta) {
		for (int i = 0; i < Banco.listaContasBancaria.size(); i++) {
			if (Banco.listaContasBancaria.get(i).getNumeroConta() == numeroConta) {
				return i;
			}
		}
		return -1;
	}

	public static void gerarRelatorio() {
		conta.mostrarDados();
	}
}