
public class ContaPoupanca extends ContaBancaria {

	private double taxaDeOperacao;

	@Override
	public void sacar(double valor) {
		Main.acoes++;
		if (this.getSaldo() > valor) {
			if (Main.acoes > 4) {
				this.setSaldo((this.getSaldo() - valor) - taxaDeOperacao);
			} else {
				this.setSaldo(this.getSaldo() - valor);
			}
		}else {
			throw new SaldoException();
		}
	}

	@Override
	public void depositar(double valor) {
		Main.acoes++;
		if (Main.acoes > 3) {
			this.setSaldo((this.getSaldo() + valor) - taxaDeOperacao);
		} else {
			this.setSaldo(this.getSaldo() + valor);
		}
	}

	@Override
	public void mostrarDados() {
		System.out.println(Main.conta.toString());
	}

	public ContaPoupanca(int numeroConta, double saldo, double taxaDeOperacao) {
		super(numeroConta, saldo);
		this.taxaDeOperacao = taxaDeOperacao;
	}

	public double getTaxaDeOperacao() {
		return taxaDeOperacao;
	}

	public void setTaxaDeOperacao(double taxaDeOperacao) {
		this.taxaDeOperacao = taxaDeOperacao;
	}

	@Override
	public String toString() {
		return super.toString() + ", TAXA DE OPERA��O: " + taxaDeOperacao + "\n";
	}
}