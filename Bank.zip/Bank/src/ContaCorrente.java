
public class ContaCorrente extends ContaBancaria {

	private double taxaDeOperacao, limite;

	@Override
	public void sacar(double valor) {
		if (valor <= limite) {
			Main.acoes++;
			if (Main.acoes > 3) {
				this.setSaldo((this.getSaldo() - valor) - taxaDeOperacao);
			} else {
				this.setSaldo(this.getSaldo() - valor);
			}
		} else {
			throw new LimiteException();
		}
	}

	@Override
	public void depositar(double valor) {
		Main.acoes++;
		if (Main.acoes > 3) {
			this.setSaldo((this.getSaldo() + valor) - taxaDeOperacao);
		} else {
			this.setSaldo(this.getSaldo() + valor);
		}
	}

	@Override
	public void mostrarDados() {
		System.out.println(Main.conta.toString());
	}

	public ContaCorrente(int numeroConta, double saldo, double taxaDeOperacao, double limite) {
		super(numeroConta, saldo);
		this.taxaDeOperacao = taxaDeOperacao;
		this.limite = limite;
	}

	public double getTaxaDeOperacao() {
		return taxaDeOperacao;
	}

	public void setTaxaDeOperacao(double taxaDeOperacao) {
		this.taxaDeOperacao = taxaDeOperacao;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	}

	@Override
	public String toString() {
		return super.toString() + ", TAXA DE OPERA��O: " + taxaDeOperacao + ", LIMITE: " + limite + "\n";
	}
}