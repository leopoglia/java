
public class LimiteException extends RuntimeException{

	private static final long serialVersionUID = -2530415291716635539L;
	
	public LimiteException() {
		super("LIMITE DA CONTA ATINGIDO!");
	}
}