
public class SaldoException extends RuntimeException{

	private static final long serialVersionUID = -4569168073147668895L;
	
	public SaldoException() {
		super("VOC� N�O TEM SALDO SUFICIENTE!");
	}
}
