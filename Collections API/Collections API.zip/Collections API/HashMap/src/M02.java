import java.util.HashMap;

public class M02 {

    public static void main(String[] args) {

        HashMap<Integer, String> numeroHashMap = new HashMap<>();

        numeroHashMap.put(1, "1");
        numeroHashMap.put(2, "2");
        numeroHashMap.put(3, "3");


        System.out.println(numeroHashMap.size());
    }
}
