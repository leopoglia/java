import java.util.TreeSet;

public class T01 {

    public static void main(String[] args) {

        TreeSet<String> coresSet = new TreeSet<String>();

        coresSet.add("Azul");
        coresSet.add("Vermelho");
        coresSet.add("Verde");

        System.out.println(coresSet);

    }
}
