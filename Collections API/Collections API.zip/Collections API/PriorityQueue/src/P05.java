import java.util.PriorityQueue;

public class P05 {

    public static void main(String[] args) {
        PriorityQueue<String> jogosPriorityQueue = new PriorityQueue<>();

        jogosPriorityQueue.add("Minecraft");
        jogosPriorityQueue.add("Fortnite");
        jogosPriorityQueue.add("League of Legends");


        jogosPriorityQueue.clear();
    }
}
